package collectionse;

import java.util.ArrayList;

public class Cde {
	
	
	
	int num;
	String name;
	float bal;
	
	
	
	
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getBal() {
		return bal;
	}
	public void setBal(float bal) {
		this.bal = bal;
	
	}


	public Cde(int num2, String nam, float bal2) {
		// TODO Auto-generated constructor stub
		
		
		super();
		this.num = num2;
		this.name = nam;
		this.bal = bal2;
	}


	public Cde() {
		// TODO Auto-generated constructor stub
	}


	

}
